using Godot; // Importa o namespace do Godot para ter acesso às classes e funcionalidades do motor
using System;

public partial class savepoint : Node2D
{
    private void OnBodyEntered(Node body)
    {
        if (body is Jogador jogador)
        {
            jogador.SavePosition(); // chama SavePosition do jogador para salvar a posição "atual" (referente ao savepoint)
            GD.Print("savepoint definido"); // mostra "savepoint definido" no console
        }
    }
}
