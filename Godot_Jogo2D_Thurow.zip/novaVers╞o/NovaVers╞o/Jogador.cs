using Godot;
using System;

public partial class Jogador : CharacterBody2D
{
    private Vector2 velocity; // velocidade atual do jogador
    private Vector2 direction; // direção do movimento do jogador
    public const float Speed = 120.0f; // regula a velocidade do jogador
    public const float MaxJumpForce = -165.0f; // força máxima do salto
    public const float MinJumpForce = -125.0f; // força mínima do salto
    public const float MaxJumpTime = 0.2f; // tempo máximo que a tecla de salto pode ser mantida pressionada
    public const int MaxDoubleJumps = 1; // número máximo de pulos duplos permitidos 
    private int doubleJumpsLeft; // número de pulos duplos restantes
    private Vector2 initialPosition; // posição inicial do jogador
    public float gravity = ProjectSettings.GetSetting("physics/2d/default_gravity").AsSingle(); // Gravidade do jogador
    public Vector2 savedPosition; // posição salva do jogador
    private Vector2 savepointPosition; // posição do ponto de salvamento
    private AnimatedSprite2D animate;
    private bool isJumping; // jogador está pulando
    private float jumpForce; // força atual do salto
    private float jumpTimer; // tempo do salto

    public override void _Ready()
    {
        animate = GetNode<AnimatedSprite2D>("AnimatedSprite2D");
        doubleJumpsLeft = MaxDoubleJumps;
        initialPosition = Position;
        savepointPosition = GlobalPosition;
    }

    public override void _PhysicsProcess(double delta)
    {
        velocity = Velocity;

        if (!IsOnFloor())
        {
            velocity.Y += gravity * (float)delta; // aplica a gravidade quando o jogador está no ar
        }
        else
        {
            doubleJumpsLeft = MaxDoubleJumps; // zera o número de pulos duplos quando o jogador está no chão p/ voltar a pular
        }

        // verifica se a tecla de salto foi pressionada
        if (Input.IsActionJustPressed("ui_accept"))
        {
            if (IsOnFloor())
            {
                isJumping = true;
                jumpForce = MaxJumpForce; //define a força máxima do salto
                jumpTimer = 0;
            }
            else if (doubleJumpsLeft > 0)
            {
                isJumping = true;
                jumpForce = MaxJumpForce; //define a força máxima do salto
                jumpTimer = 0;
                doubleJumpsLeft--;
            }
        }

        if (isJumping)  //se stiver pulando:
        {
            // verifica se a tecla de salto está sendo mantida pressionada e atualiza a força do salto com base no tempo decorrido
            if (Input.IsActionPressed("ui_accept") && jumpTimer < MaxJumpTime)
            {
                jumpForce = Mathf.Lerp(MaxJumpForce, MinJumpForce, jumpTimer / MaxJumpTime);
                jumpTimer += (float)delta;
            }
            else
            {
                isJumping = false; //o jogador parou de pular
            }
        }

        direction = Input.GetVector("ui_left", "ui_right", "ui_up", "ui_down");

        if (direction != Vector2.Zero)
        {
            velocity.X = direction.X * Speed;
        }
        else
        {
            velocity.X = Mathf.MoveToward(Velocity.X, 0, Speed);
        }

        if (isJumping)
        {
            velocity.Y = jumpForce; //Aplica a força de salto atual à velocidade vertical
        }

        Velocity = velocity; //Aplica a nova velocidade ao jogador

        MoveAndSlide(); //função para o jogador se mover e coledir com as coisas

        Animation(velocity); //rtualiza a animação do jogador com base em sua velocidade

        if (Position.Y > 450)   //ponto q ele cai no void e volta
        {
            ResetPlayer(); //reinicia o jogador se ele cair abaixo de uma determinada altura
        }
    }

    // atualiza a animação do jogador:
    private void Animation(Vector2 velocity)
    {
        if (!IsOnFloor())
        {
            animate.Play("jump");
        }
        else
        {
            if (velocity.X != 0)
            {
                animate.Play("run");
            }
            else
            {
                animate.Play("idle");
            }
        }
        //espelhar a animação do personagem
        if (velocity.X != 0)
        {
            if (velocity.X < 0)
            {
                animate.FlipH = true; // inverte a animação
            }
            else
            {
                animate.FlipH = false; // mantém a animação normal
            }
        }
    }

    // reinicia o jogador para sua posição inicial
    private void ResetPlayer()
    {
        Position = savepointPosition;
        Velocity = Vector2.Zero;
    }

    // salva a posição atual do jogador
    public void SavePosition()
    {
        savepointPosition = Position;
    }

    // restaura a posição salva do jogador
    public void ClearSavedPosition()
    {
        Position = savepointPosition;
        savedPosition = savepointPosition;
        Velocity = Vector2.Zero;
    }

    // retorna à posição do ponto de salvamento
    public void ReturnToSavePoint()
    {
        GlobalPosition = savepointPosition;
        savedPosition = savepointPosition;
        Velocity = Vector2.Zero;
    }
}
